# Software Requirements

## 1\. Introduction

Washington Vets2Tech was developed for service members transitioning out of the military and provides training that will leverage their current skills and experience in order to secure a job in technology. Previously, Saint Martin's hosted an on-campus program of the Microsoft Software & Systems Academy, though this program has exclusively moved to an online-only platform. Vets2Tech was created to mirror this program to still allow veterans the ability to receive hands-on training with instructor supervision. Unfortunately these service members would not receive access to the MSSA Hiring Partners portal that was previously provided, so this project began so Vets2Tech will still be able to provide the benefits of job searching after the certificate program.

### 1.1 Purpose

### 1.2 Document Conventions

### 1.3 Intended Audience

This is

### 1.4 Product Scope

Vets2Tech Web Application is a job-hunting website specifically for students enrolled in Washington Vets2Tech at Saint Martin’s University. Students create profiles highlighting their employable skills, which are available to Vets2Tech employer network. The purpose of this application is to connect students with employment opportunities.

  

### 1.5 References

## 2\. Description

### 2.1 Product Perspective

Usability

1. Simple to navigate for employers seeking veteran candidates for open positions.
2. Easily browsed by veteran students to find job postings matching their skills and interests.
3. Provides filtering features for both employer and student users, allowing for additional categories relevant to veterans such as security clearance status.

### 2.2 Product Functions

WAVets2Tech Portal Benefits

Internal Benefits

1.            Integration: The ability for WAV2T to integrate and unite all customer (Student) and corporate data in the back end of a single system which can greatly ease administration operations.

  

2.            Personalization: Portal will be built to allow personalized access to specific users, giving WAV2T the ability to contextualize the experiences of both customers (Students) and external companies.

  

External Benefits

1.            Access Control: WAV2T can control who can access their internal cloud repositories and can also control what said parties could access via secure authentication and authorization (web-based) mechanisms.

  

### 2.3 User Classes and Characteristics

#### 2.3.1 Students

Profile customization is highest priority and must include:

*   Fields for contact information
*   Education Background section with ability to add more than one
*   Employment History with the ability to add more than one
*   Military background section with specific fields for reporting previous MOS, certificates earned while enlisted, security clearance status, and other possible relevant considerations such as reason for discharge
*   File storage within the user's account for a resume

Other features student users will need:

*   Search filtering options to browse available job postings
*   Ability to save job postings for later reference
*   Ability to save Employer contact information or profiles for communication

#### 2.3.2 Employers

Company profile and landing pages are needed as well as functions for these users as follows:

*   Company and Employer display/profile pictures
*   Profile fields applicable to the Employer's needs, such as fields for current job positions the Employer user holds as well as overview sections
*   Ability to create job postings for potential student candidates to browse
*   Search and filtering options to view student candidates
*   Options for saving candidate profiles for later use
*   Communication options to contact potential student candidates

#### 2.3.3 Vets2Tech Staff

Admin accounts with the highest access permissions need to be established allowing for the following features:

*   Company profile creation
*   Employer profile creation
*   Student profile creation
*   Student profile approval
*   Edit function for all profile instances
*   Delete function for all profile instances
*   Integrated display to show help request tickets for user issues submitted

### 2.4 Operating Environment

### 2.5 Design and Implementation Constraints

Design constraints are currently present with the React.js and .Net integrated structure. Implementation of user authentication is not currently built and a chosen method for authentication would need to be decided.

#### 2.5.1 Delivery Date

#### 2.5.2 Technology Stack

React.js web application for user-side development, [ASP.NET](http://ASP.NET) Core 6.0 for the web api. Current database is created within Sql Server and reference documents for relationship structure are available as well as column fields including comments.

#### 2.5.3 Documentation

### 2.6 Assumptions and Dependencies

## 3\. External Interface Requirements

### 3.1 User Interfaces

#### 3.1.1 Student Interface

#### 3.1.2 Employer Interface

#### 3.1.3 Administrator Interface

#### 3.1.4 Home Page

### 3.2 Hardware Interfaces

### 3.3 Software Interfaces

### 3.4 Communications Interface

#### 3.4.1 Back End

#### 3.4.2 Public Web Front End

## 4\. System Features

### 4.1 Student Features